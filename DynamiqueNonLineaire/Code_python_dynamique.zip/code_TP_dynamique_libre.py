# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 05:18:31 2022

@author: adm-grolet
"""

import numpy as np
from matplotlib import pyplot as plt
from scipy import integrate

plt.close('all') # close all graph windows

# nonlinear coefficient gamma
gamma = 1 

def eq_sys_lineaire_libre(y, t):
    # function definig the single dof free linear oscillator (no damping, no forcing, no nonlinearity)
    # we set y[0] = q and y[1] = dq/dt
    dy0 = y[1]       # dq/dt = dy[0]/dt = y[1]
    dy1 = - y[0]     # d2q/dt2 = dy[1]/dt = -q = -y[0]  # modify here to include nonlinearity
    return [dy0, dy1]

def plot_time_signal(t_eval, sol):
    # plot the results in time domain
    plt.figure()
    plt.subplot(2,1,1) # position as a function of time
    plt.plot(t_eval, sol[:,0])
    plt.xlabel('time')
    plt.ylabel('position')
    plt.title('time series')
    plt.subplot(2,1,2) # velocity as a function of time
    plt.plot(t_eval, sol[:,1])
    plt.xlabel('time')
    plt.ylabel('velocity')

def plot_in_phase_space(sol):
    # plot the results in the phase space
    plt.figure()
    plt.plot(sol[:,0], sol[:,1])
    plt.xlabel('position')
    plt.ylabel('velocity')
    plt.title('phase space')
    
# integrate from initial condition
y_init = [1, 0 ]                      # initial condition [position, velocity]
t_eval = np.linspace(0, 10, 1000)     # time interval for integration
# call the solver
sol = integrate.odeint(eq_sys_lineaire_libre, y_init, t = t_eval)
# plot the results in time domain
plot_time_signal(t_eval, sol)
# plot the results in phase space
plot_in_phase_space(sol)
