# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 05:18:31 2022

@author: adm-grolet
"""

import numpy as np
from matplotlib import pyplot as plt
from scipy import integrate

plt.close('all') # close all graph windows

# nonlinear coefficient gamma
gamma = 1 
mu = 0.2

def eq_sys_lineaire_amorti_force(y, t, f, Omega_f):
    # function definig the single dof free linear oscillator (no damping, no forcing, no nonlinearity)
    # we set y[0] = q and y[1] = dq/dt
    dy0 = y[1]                                      # dq/dt = dy[0]/dt = y[1]
    dy1 = - y[0] -mu*y[1] + f*np.sin(Omega_f*t)     # d2q/dt2 = dy[1]/dt = -q + mu dq/dt + f(t) = -y[0] - mu y[1] + f sin (Omega t)  # modify here to include nonlinearity
    return [dy0, dy1]

def plot_time_signal(t_eval, sol):
    # plot the results in time domain
    plt.figure()
    plt.subplot(2,1,1) # position as a function of time
    plt.plot(t_eval, sol[:,0])
    plt.xlabel('time')
    plt.ylabel('position')
    plt.title('time series')
    plt.subplot(2,1,2) # velocity as a function of time
    plt.plot(t_eval, sol[:,1])
    plt.xlabel('time')
    plt.ylabel('velocity')

def plot_in_phase_space(sol):
    # plot the results in the phase space
    plt.figure()
    plt.plot(sol[:,0], sol[:,1])
    plt.xlabel('position')
    plt.ylabel('velocity')
    plt.title('phase space')
    
def plot_poincare_map(sol):
    # plot the results at each period in the phase space = poincarre map
    plt.figure()
    for n in range(len(sol[:,0])):
        plt.plot(sol[n,0], sol[n,1],'.')
    plt.xlabel('position')
    plt.ylabel('velocity')
    plt.title('Poincarre map')
    plt.axis([-5, 5, -5, 5])



# forcing amplitude and pulsation
f = 0.1
Omega_f = 1

# some useful stuff
period = 2*np.pi/Omega_f              # period of the forcing signal
number_of_period = 100                # number of period for the time integration
number_of_step_per_period = 50        # number of time step per period
dt = period/number_of_step_per_period # time step
Tf = number_of_period*(period)        # final time for integration (100 periods)
number_of_step_total = number_of_period*number_of_step_per_period+1      # number of time step between 0 and Tf
Q = 1/mu                              # quality factor
number_of_period_transiant = int(np.floor(3*Q+1))
n_steady = int(np.floor(3*Q*period/dt + 1))     # number of time step after wich the transiant disapear (after 3*Q period
                                                # i.e. the steady states starts at t_eval(n_steady)

# time range for the integration
t_eval = np.linspace(0, Tf, number_of_step_total)     # time interval for integration
# integrate from initial condition
y_init = [0, 0 ]    # initial condition [position, velocity]
# call the solver
sol = integrate.odeint(eq_sys_lineaire_amorti_force, y_init, t = t_eval, args=(f, Omega_f))
sol_steady = sol[n_steady:,:] # extract the steady state solution
t_steady = t_eval[n_steady:]  # extract the time range for the steady state

# plot the full results in time domain (transiant  + steady state)
plot_time_signal(t_eval, sol)
# plot the full results in phase space (transiant + steady state)
plot_in_phase_space(sol)

# plot only the steady state results in time domain
plot_time_signal(t_steady, sol_steady)
# plot only th steady state in phase space 
plot_in_phase_space(sol_steady)

# plot the poincarre map
step_range = range(n_steady, number_of_step_total, number_of_step_per_period) # index of the solution at each time Tn = n 2 pi / omega_f
plot_poincare_map(sol[step_range,:])
